package com.example.newsapp.Data

data class NewsData (

    var Title: String,
    var Description: String,
    var TimeStamp: String,
    var Author: String,
    var urlToImage: String,
    var urlToArticle: String
)

package com.example.newsapp.viewmodel

import com.example.newsapp.API.ApiService

    class MainRepository constructor(private val apiService: ApiService) {
        fun getNews() = apiService.getNews()
    }

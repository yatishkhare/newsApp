package com.example.newsapp.Adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.newsapp.Data.NewsData
import com.example.newsapp.databinding.NewsItemBinding

class MainAdapter: RecyclerView.Adapter<MainViewHolder>() {
    var news = mutableListOf<NewsData>()
    fun setNewsList(newsList: List<NewsData>) {
        this.news = newsList.toMutableList()
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = NewsItemBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }
    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val _news = news[position]
        holder.binding.tvTitle.text = _news.Title
        Glide.with(holder.itemView.context).load(_news.urlToImage).into(holder.binding.imageView)
    }
    override fun getItemCount(): Int {
        return news.size
    }
}
class MainViewHolder(val binding: NewsItemBinding) : RecyclerView.ViewHolder(binding.root) {

}
package com.example.newsapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.newsapp.Data.NewsData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel constructor(private val repository: MainRepository)  : ViewModel() {

        val newsList = MutableLiveData<List<NewsData>>()
        val errorMessage = MutableLiveData<String>()

        fun getNews() {
            val response = repository.getNews()
            response.enqueue(object : Callback<List<NewsData>> {
                override fun onResponse(call: Call<List<NewsData>>, response: Response<List<NewsData>>) {
                    newsList.postValue(response.body())
                }
                override fun onFailure(call: Call<List<NewsData>>, t: Throwable) {
                    errorMessage.postValue(t.message)
                }
            })
        }
    }
